<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Model {
    public function page($type)
	{
		
			$arr=array('title'=>'Registration Form','data'=>'Fill out the form');
		
		return $arr;
	}
	public function insert_data($data)
	{
		$this->db->insert('student',$data);
	}
	
	
	public function update_data($id,$data)
	{
		$this->db->where('id',$id);
		$this->db->update('student',$data);
	}
	
	
	public function delete_data($data)
	{
		$this->db->delete('student',$data);
	}
	
	
	public function get_data($id)
	{
		//$query=$this->db->get('contact');
		
		$this->db->select('city,name');
		$this->db->from('contact');
		$this->db->where('id',$id);
		$query=$this->db->get();
		return $query->result();
	}
	
	
}

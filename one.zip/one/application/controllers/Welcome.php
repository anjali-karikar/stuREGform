<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	public function __construct(){
		parent::__construct();
		$this->load->model('home');
	}
	public function index()
	{
		$arr['data']=$this->home->page('home');
		$this->load->view('header');
		$this->load->view('page',$arr);
		$this->load->view('footer');
	}

	
	public function insert_data()
	{   $config['upload_path']          = 'https://kombretum.online/one/applications/assets/marksheet';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('filename'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_success', $data);
                }
        
        
        
        $interestsArray=$this->input->post('interest');
        //  foreach($interestsArray as $t){
        //      $data['interests']=$t.',';
        //  }
        $da=implode(",",$interestsArray);

		
		$data['fname']=$this->input->post('fname');
		$data['mname']=$this->input->post('mname');
		$data['lname']=$this->input->post('lname');
		$data['dob']=$this->input->post('dob');
		$data['gender']=$this->input->post('radios');
		$data['address']=$this->input->post('Address');
		$data['phone']=$this->input->post('phone');
		$data['interests ']=$da;
		$data['marksheet']=$this->input->post('filename');
		$data['photo']=$this->input->post('filename2');
		$data['last_yr_marks']=$this->input->post('marks');
		$this->home->insert_data($data);
	}
	
	public function update_data()
	{
	     $config['upload_path']          = 'https://kombretum.online/one/applications/assets/marksheet';
                $config['allowed_types']        = 'gif|jpg|png';
                $config['max_size']             = 100;
                $config['max_width']            = 1024;
                $config['max_height']           = 768;

                $this->load->library('upload', $config);

                if ( ! $this->upload->do_upload('filename'))
                {
                        $error = array('error' => $this->upload->display_errors());

                        $this->load->view('upload_form', $error);
                }
                else
                {
                        $data = array('upload_data' => $this->upload->data());

                        $this->load->view('upload_success', $data);
                }
		$data['fname']=$this->input->post('fname');
		$data['mname']=$this->input->post('mname');
		$data['lname']=$this->input->post('lname');
		$data['dob']=$this->input->post('dob');
		$data['gender']=$this->input->post('radios');
		$data['address']=$this->input->post('Address');
		$data['phone']=$this->input->post('phone');
		$data['interests ']=$da;
		$data['marksheet']=$this->input->post('filename');
		$data['photo']=$this->input->post('filename2');
		$data['last_yr_marks']=$this->input->post('marks');
		$this->home->update_data($id,$data);
	}
	public function delete_data()
	{
		$data['id']->input->get('id');
		$this->home->delete_data($data);
	}
	public function get_data()
	{
		$arr=$this->home->get_data(2);
		echo '<pre>';
		print_r($arr);
	}

}

<div class="container" >
      <!--<h1 style="text-align: center;">Registration Form</h1>-->
      <h1 style="text-align: center;"><?php echo $data['title']?></h1>
	  <div>
	<h3"><?php echo $data['data']?></h3>
	  </div>
	<form action="insert_data" method="post" enctype="multipart/form-data">
          <div class="form-row">
            <div class="form-group col-md-4">
              <label for="fname">First Name</label>
              <input type="text" class="form-control" id="fname" name="fname" placeholder="First Name">
            </div>
            <div class="form-group col-md-4">
              <label for="mname">Middle Name</label>
              <input type="text" class="form-control" id="mname" name="mname" placeholder="Middle Name">
            </div>
            <div class="form-group col-md-4">
              <label for="lname">Last Name</label>
              <input type="text" class="form-control" id="lname" name="lname" placeholder="Last Name">
            </div>
          </div>
          
         
  
  
          <div class="form-row">
              <div class="col-md-6 col-sm-6">
              <label for="dob">Date of birth:</label>
              <input type="date" id="dob" name="dob" name="birthday">
              </div>
              
              <label class="form-check col-md-2 col-sm-2">Gender :</label>
              <div class="form-check col-md-2 col-sm-2">
                  <input class="form-check-input" type="radio" name="radios" id="exampleRadios1" value="male">
                  <label class="form-check-label" for="exampleRadios1">
                    Male
                  </label>
                </div>
            <div class="form-check col-md-2 col-sm-2">
              <input class="form-check-input" type="radio" name="radios" id="exampleRadios2" value="female">
              <label class="form-check-label" for="exampleRadios2">
                Female
              </label>
            </div>
            </div>
            

          <div class="form-row col-md-12">
            <label for="inputAddress">Address</label>
            <textarea class="form-control" id="inputAddress" name="Address" rows="2" ></textarea>
          </div>
          
          <div class="form-row">
            <div class="form-group col-md-12">
              <label for="phone">Phone</label>
              <input type="text" class="form-control" id="phone" name="phone">
            </div>
            </div>
           
           <div class="form-row">
           <div class="form-group col-md-6">
               <label for="">Interested in :</label>
           </div>
           <div class="form-group col-md-6">
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox1" value="Arts" name="interest[]">
              <label class="form-check-label" for="inlineCheckbox1">Arts</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox2" value="Science" name="interest[]">
              <label class="form-check-label" for="inlineCheckbox2">Science</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox3" value="HScience" name="interest[]">
              <label class="form-check-label" for="inlineCheckbox3">Home Science</label>
            </div>
            <div class="form-check form-check-inline">
              <input class="form-check-input" type="checkbox" id="inlineCheckbox4" value="computer" name="interest[]">
              <label class="form-check-label" for="inlineCheckbox4">Computer</label>
            </div>
            </div>
            </div>
            
            <div class="form-row">
           <div class="form-group col-md-2">
                <label for="myFile">Marksheet : </label>
                </div>
            <div class="form-group col-md-10">                
                <input class="form-group" type="file" id="myFile" name="filename" >
            </div>
            </div>
            
            <div class="form-row">
           <div class="form-group col-md-2">
                <label for="myFile2">Photo : </label>
                </div>
            <div class="form-group col-md-10">                
                <input class="form-group" type="file" id="myFile2" name="filename2" >
            </div>
            </div>

           
            <div class="form-group col-md-12">
              <label for="marks">Last year Marks</label>
              <input type="text" class="form-control" id="marks" name="marks">
            </div>
            
            <div class="container ">
          <input type="submit" class="form-group btn btn-primary"  value="Save"></div>
</form>
	 
    </div>
    